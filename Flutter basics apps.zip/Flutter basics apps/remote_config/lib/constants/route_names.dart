const String LoginViewRoute = "LoginView";
const String SignUpViewRoute = "SignUp";
const String HomeViewRoute = "HomeView";
const String CreatePostViewRoute = "CreatePostView";
// Generate the views here
