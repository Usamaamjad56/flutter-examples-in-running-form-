const String LoadingIndicatorTitle = '^';
