import 'package:flutter/material.dart';

void main() {
  runApp(CardApp());
}

class CardApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      home: Scaffold(
        backgroundColor: Colors.red,
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                backgroundColor: Colors.green,
                backgroundImage: AssetImage('images/user.png'),
              ),

         Text('Usama Amjad',
              style: TextStyle(
               color: Colors.black,
               fontSize: 30,
               fontWeight: FontWeight.bold,

                ),
    ),

             Text('FLUTTER DEVELOPER',
        style: TextStyle(
          color: Colors.black,
          fontSize: 30,
          fontWeight: FontWeight.bold,
          letterSpacing: 2.0,

             ),
             ),
               SizedBox(width: 500.0,
                 height: 20.0,
                 child: Divider(
                   color: Colors.white,

                       ),

                ),
                 Card(margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                    child: ListTile(
                   leading: Icon(Icons.phone),
                   title: Text('03015512804',
                  style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,

                      ),

                   ),
                    ),
                      ),
                     Card(margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
                          child: ListTile(
                           leading: Icon(Icons.email),
                             title: Text('zainiftikhar20@gmail.com',
                            style: TextStyle(
                            color: Colors.black,
                             fontSize: 20,

                             ),
                             ),
                             ),
                             ),

                             ],
    ),
    ),
    ),
     };
}

